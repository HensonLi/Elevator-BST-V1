#include "usbport.h"

UsbPort::UsbPort(QObject *parent) : QObject(parent)
{

}
UsbPort::~UsbPort()
{

}
