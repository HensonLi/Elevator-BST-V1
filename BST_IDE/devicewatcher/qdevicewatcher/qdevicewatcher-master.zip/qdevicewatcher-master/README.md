QDeviceWatcher can detect usb storage add and remove event.
Tested on linux (>= 2.6) and windows(mingw and msvc). WinCE is to be tested.

Thanks qdrive project for the win32 part: https://gitorious.org/qdrive/qdrive

Screenshot
-----

![Alt text](https://github.com/wang-bin/qdevicewatcher/raw/master/screenshot/ubuntu.png              "Ubuntu non-debug")
![Alt text](https://github.com/wang-bin/qdevicewatcher/raw/master/screenshot/ubuntu-gui-debug.png    "Ubuntu gui debug")
![Alt text](https://github.com/wang-bin/qdevicewatcher/raw/master/screenshot/win7.png                "Win7 non-debug")
![Alt text](https://github.com/wang-bin/qdevicewatcher/raw/master/screenshot/win7-gui-debug.png      "Win7 gui debug")
![Alt text](https://github.com/wang-bin/qdevicewatcher/raw/master/screenshot/wince-emu-gu.png        "WinCE emulater")

