/****************************************************************************
** Meta object code from reading C++ file 'hotplugwatcher_gui.h'
**
** Created: Mon Sep 9 09:55:07 2013
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../test/hotplugwatcher_gui.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'hotplugwatcher_gui.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_HotplugWatcher_GUI[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      20,   19,   19,   19, 0x0a,
      39,   34,   19,   19, 0x0a,
      60,   56,   19,   19, 0x0a,
      85,   56,   19,   19, 0x0a,
     112,   56,   19,   19, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_HotplugWatcher_GUI[] = {
    "HotplugWatcher_GUI\0\0toggleWatch()\0"
    "show\0showDetail(bool)\0dev\0"
    "slotDeviceAdded(QString)\0"
    "slotDeviceRemoved(QString)\0"
    "slotDeviceChanged(QString)\0"
};

void HotplugWatcher_GUI::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        HotplugWatcher_GUI *_t = static_cast<HotplugWatcher_GUI *>(_o);
        switch (_id) {
        case 0: _t->toggleWatch(); break;
        case 1: _t->showDetail((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->slotDeviceAdded((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->slotDeviceRemoved((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->slotDeviceChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData HotplugWatcher_GUI::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject HotplugWatcher_GUI::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_HotplugWatcher_GUI,
      qt_meta_data_HotplugWatcher_GUI, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &HotplugWatcher_GUI::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *HotplugWatcher_GUI::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *HotplugWatcher_GUI::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_HotplugWatcher_GUI))
        return static_cast<void*>(const_cast< HotplugWatcher_GUI*>(this));
    return QWidget::qt_metacast(_clname);
}

int HotplugWatcher_GUI::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
